javac -classpath ../lib/jade.jar -d classes FTPAgent.java FTPUtils.java
