java -cp ../lib/jade.jar:classes jade.Boot -gui

