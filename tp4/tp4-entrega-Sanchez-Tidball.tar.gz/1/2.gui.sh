java -cp ../lib/jade.jar:classes myexamples.MultipleContainers
