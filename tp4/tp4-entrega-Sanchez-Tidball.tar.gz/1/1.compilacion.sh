javac -classpath ../lib/jade.jar -d ./classes ./myexamples/AgenteMovil.java ./myexamples/MultipleContainers.java
