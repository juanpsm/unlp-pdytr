javac -classpath ../lib/jade.jar -d ./classes ./myexamples/MonitoringAgent.java
