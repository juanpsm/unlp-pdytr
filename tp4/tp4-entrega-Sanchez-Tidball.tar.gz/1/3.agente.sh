java -cp ../lib/jade.jar:classes jade.Boot -container -host localhost -port 1099 -agents "AgenteMovil:myexamples.AgenteMovil()"
